#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
const string propFile = "UnicodeDataV2.txt";
int main() {

    // Testing for get method with a single argument with a different property file
    try{ 
    	U u; 
    	P p;
    	p.readfile("UnicodeDataV2.txt");
    	u.readfile("story.txt");
    	cout << "Get: " << u.get(50) << '\n';
    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }

    return 0;
}
