#include "U.h"
#include "P.h"
#include <iostream>

using namespace std;

int main() {

    // Testing append method which should throw an error 
    U u;
    try {
        u.append("\xFF");        // not a valid UTF-8 string;
    }
    catch (string s) {
        cout << "Good: caught error as expected\n";
    }
    catch (...) {
        cout << "Bad unexpected type caught\n";
    }


    return 0;
}
