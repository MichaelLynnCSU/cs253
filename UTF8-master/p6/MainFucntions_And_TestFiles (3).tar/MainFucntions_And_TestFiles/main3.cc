#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
const string pub="/s/bach/a/class/cs253/pub/";   // ~ only works in shells
const string readfile = "data1";
int main() {

    // Test for Assignment operator
    // Testing Append method in U class
    // Testing get method without argument  
    try{ 
    	U u;
    	u.readfile(readfile);
   	U u2;
    	u2 = u;
    	u2.append("Checking for appending feature in this assignment");
    	P p;
    	p.readfile(pub+"UnicodeData.txt"); 
    	P p2;
    	p2 = p; 
    	cout << "Get: " << u2.get() << '\n';
	for (int i=0; i<u2.size(); i++)
            p2.count(u2.codepoint(i));

        cout << "Ll: " << p2.count("Ll") << '\n';

    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }


    return 0;
}
