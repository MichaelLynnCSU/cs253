#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
int main() {

    // Testing destructor
    try{
    	U *u = new U();  
    	u->~U();
    	cout << "Testing destructor for U" << '\n';
    	P *p = new P();
    	p->~P();
    	cout << "Testing destructor for P" << '\n';
    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }

    return 0;
}
