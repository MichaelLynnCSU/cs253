#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
const string pub="/s/bach/a/class/cs253/pub/";   // ~ only works in shells
const string propFile = "UnicodeDataV2.txt";
int main() {

    // Test for both Copy Constructors and get method with two arguments
    try{ 
    	U u;
    	P p;
    	u.readfile("story.txt");
    	p.readfile(propFile);
    	U u1 = u;
    	P p1 = p;
    	cout << "Get: " << u1.get(23, 47) << '\n'; 
	for (int i=0; i<u1.size(); i++)
            p1.count(u1.codepoint(i));

        cout << "Lu: " << p1.count("Lu") << '\n';

    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }

    return 0;

}
