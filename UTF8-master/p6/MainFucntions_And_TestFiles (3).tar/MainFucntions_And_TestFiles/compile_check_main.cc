#include "U.h"
#include "P.h"
#include <iostream>

int main() {
    std::cout << "Compile Success" << '\n';
    return 0;

}

