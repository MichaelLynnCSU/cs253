#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
int main() {

    // Testing for props() method and invlaid count in property   
    // Testing error in filename constructor
 
    try
    {
    	U foo;
	foo.append("5xyz + 2xy19z - 0.4567xyz - 106347200y + 0.34527");
    	P foo1("UnicodeDataV4.txt");
	for (int i=0; i<foo.size(); i++)
            foo1.count(foo.codepoint(i));
        cout << "Nirvana: " << foo1.count("Nirvana") << '\n';
    	for (const auto &p : foo1.props())
		cout << "Property: " << p << '\n';

        U u("something");
    }
    catch(string caught)
    {
        cout << "Throws: " << caught << endl;
    }
    return 0;
}
