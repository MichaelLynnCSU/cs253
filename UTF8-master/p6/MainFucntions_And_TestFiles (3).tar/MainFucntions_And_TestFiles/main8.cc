#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
int main() {

    // Error check for invalid property file
 
    try{
    	P p4;
        p4.readfile("UnicodeData.txt");
    }
    catch(string caught)
    {
        cout << "Throws: " << caught << endl;
    }
 
    return 0;
}
