#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
int main() {

    // Error check for bad readfile

    try{
    	U u3;
        u3.readfile("okay.doc"); 
    }
    catch(string caught)
    {
        cout << "Throws: " << caught << endl;
    }
 
    
    return 0;
}
