#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
const string propFile = "UnicodeDataV2.txt";
int main() {

    // Error check for invalid range arguments in get method

    try{
    	U u1; 
	P p1;
    	u1.readfile("story.txt");
    	p1.readfile(propFile);
        u1.get(-1, 4); // Error check for invlid argument
    }
    catch(string caught)
    {
	cout << "Throws: " << caught << std::endl;
    }
    return 0;
}
