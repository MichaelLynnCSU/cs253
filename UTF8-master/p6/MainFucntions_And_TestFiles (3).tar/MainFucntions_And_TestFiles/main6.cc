#include "U.h"
#include "P.h"
#include <iostream>
using namespace std;
const string pub="/s/bach/a/class/cs253/pub/";   // ~ only works in shells
int main() {

    // Error check for invalid single argument

    try{
    	U u2;
	P p2;
    	u2.readfile("data1");
    	p2.readfile(pub+"UnicodeData.txt"); 
        u2.get(8828636); // Error statement for invlid argument
    }
    catch(string caught)
    {
        cout << "Throws: " << caught << endl;
    }

    return 0;
}
