#include "U.h"
#include <iostream>
#include <cassert>

using std::cout;
using std::hex;
using std::showbase;

// Testing returned value from iterator increment


int main() {

     U u;
     u = "0123456789";
     auto a = u.begin();
     auto b = a++;
     assert(*a == '1');
     assert(*b == '0');     // b must get old iterator value
     assert(a != b);

     a = u.begin();
     b = ++a;
     assert(*a == '1');
     assert(*b == '1');     // b must get new iterator value
     assert(a == b);

     cout << "Success" << '\n';

}
