#include "U.h"
#include <iostream>
#include <cassert>

using std::cout;
using std::hex;
using std::showbase;

// Testing U::iterator methods


int main() {

    U u;
    u = "\u0B2E \u0B41 08 \u0B17 \u0B4B \u0B13 05 \u0B21 \u0B3F \u0B06";

    U::iterator it; // default constructor

    // Copy Constructor and Assignment Operator
    U::iterator it1 = it; 
    U::iterator it2;
    it2 = it1;

    U::iterator it3;
    it3 = u.begin();

    it3++;
    assert(*it3 == ' ');
    ++it;
    assert(*it3 != 0x0B2E);		
    it3 = u.end();
    --it3;
    assert(*it3 == 0x0B06);		

    for (auto cp : u)
	cout << hex << showbase << cp << ' ';
    cout << '\n';
}
