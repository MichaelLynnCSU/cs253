#include "U.h"
#include <iostream>
#include <cassert>

using std::cout;
using std::hex;
using std::showbase;
using namespace std;

// Testing error cases when U(iter, iter) thorws an error


int main() {
    
    try{
    	const char s[] = "\xFF";
    	U u(s, s+sizeof(s)-1);
    }
    catch (string s) {
        cout << "Good: caught error as expected\n";
    }
    catch (...) {
        cout << "Bad unexpected type caught\n";
    }
    return 0;

}
