#include "U.h"
#include <iostream>
using namespace std;
int main() {

    // Testing for Append of U objects
    try{ 
    	U u; 
    	u.readfile("data3");

	U u1;
	u1.append("Only I can change my life. No one can do it for me.");

	u += u1;
	cout << "u: " << u << endl; 
	cout << "No change u1: " << u1 << endl;
    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }

    return 0;
}
