#include "U.h"
#include <iostream>

using namespace std;
const string readfile = "data1";
int main() {

    // Test for Assignment operator
    // Testing Append method in U class
    // Testing get method with a single argument
    // Test for concatenation of U objects

    try{ 
    	U u;
    	u.readfile(readfile);
   	U u2;
    	u2 = u;
    	u2.append("The Doors were an American rock band formed in 1965 in Los Angeles.");

    	cout << "Get: " << u2.get(20) << '\n';

	U u3;
	u3.readfile("data2");
	
	cout << "u2 + u3: " << u2 + u3 << endl;
	cout << "No chage u2: " << u2 << endl;
	cout << "No chage u3: " << u3;
	
    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }


    return 0;
}
