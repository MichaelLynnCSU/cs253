#include "U.h"
#include <iostream>
#include <cassert>

using namespace std;

int main() {

    // Testing for Comparison 
    try {
    	U u;
        u.append("\u0B67 Jack Applin"); 

	assert(u == u);
	
	U u1;
	u1.append("\u0B6B Pratik Warade");
	const string test = "\u0B6B Pratik Warade";
	assert(u1 == test);

	U u2;
        u2.append("\u0B6E Sam Maxwell");
        const string test1 = "\u0B6E Sam Maxwell";
        assert(u2 == test1);

	const U u4 = u;
	assert(u4);
	assert(u4 != u1);
	assert(u1 != test1);
	assert(test != u2);

        cout << "Success" << '\n';

    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }


    return 0;
}
