#include "U.h"
#include <iostream>
#include <cassert>

using std::cout;
using std::hex;
using std::showbase;

// Testing all U methods


int main() {
    const char s[] = "\u0B2E \u0B41 08 \u0B17 \u0B4B \u0B13 05 \u0B21 \u0B3F \u0B06";

    U u(s, s+sizeof(s)-1);
    assert(u == "\u0B2E \u0B41 08 \u0B17 \u0B4B \u0B13 05 \u0B21 \u0B3F \u0B06");
    cout << u << '\n';			

    assert(u.front() == 0x0B2E);	
    assert(u.back() == 0x0B06);		
    U::iterator it = u.begin();
    assert(*it == 0x0B2E);		
    it++;
    assert(*it == ' ');
    it = u.end();
    --it;
    assert(*it == 0x0B06);		

    for (auto cp : u)
	cout << hex << showbase << cp << ' ';
    cout << '\n';
}
