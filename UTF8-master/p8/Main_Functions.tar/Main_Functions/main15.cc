#include "U.h"
#include <iostream>
using namespace std;
int main() {

    // Boolean evaluation
    try{
    	U u;
	u.readfile("story.txt");

	if(u)
	{
	    cout << "First True" << '\n';
	}
	
	U u1;
	if(!u1)
        {
            cout << "Second False" << '\n';
        }

    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }

    return 0;
}
