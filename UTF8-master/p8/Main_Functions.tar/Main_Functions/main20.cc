#include "U.h"
#include <iostream>
#include <cassert>

using std::cout;
using std::hex;
using std::showbase;

// Testing returned value from iterator decrement


int main() {

     U u;
     u = "0123456789";
     auto a = u.begin();
     auto b = ++a;
     auto c = b--;
     assert(*c == '1');
     assert(*b == '0');     // b is decremented
     assert(c != b);

     a = u.end();
     b = --a;
     assert(*a == '9');
     assert(*b == '9');     // b must get new iterator value
     assert(a == b);

     cout << "Success" << '\n';

}
