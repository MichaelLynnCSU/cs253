#include "U.h"
#include <iostream>
#include <cassert>

using std::cout;
using std::hex;
using std::showbase;
using namespace std;

// Testing when the .front() method throws an error

int main() {
    try{
    	const char s[] = "";

    	U u(s, s+sizeof(s)-1);
    	u.front();	
    }
    catch (string s) {
	cout << "Throws: " << s << "\n";
    }
    catch (...) {
        cout << "Bad unexpected type caught\n";
    }

}
