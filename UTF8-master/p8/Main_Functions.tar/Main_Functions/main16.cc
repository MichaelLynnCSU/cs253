#include "U.h"
#include <iostream>
using namespace std;
int main() {

    // Testing for constant argument in readfile 
    
    try{ 
    	U foo;
    	const string filename = "data1";
    	foo.readfile(filename);    
    	cout << "Testing for constant argument in readfile" << '\n';
    }
    catch (const string &msg) {
        cout << "Unexpected error: " << msg << '\n';
    }

    return 0;
}
